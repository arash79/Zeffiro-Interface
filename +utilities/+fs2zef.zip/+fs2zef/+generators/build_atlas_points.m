function points = build_atlas_points(subject_dir, out_dir, atlas_schemes)
%
% build_atlas_points - Generate FreeSurfer parcellation point files for one
% or more atlas schemes and write them into out_dir.
%
% For each requested scheme and hemisphere, the function runs
% mri_annotation2label and mri_mergelabels to produce a merged label file
% (<hh>_labels_<id>.asc).
%
% Inputs:
%
% - subject_dir (1,1) string
%
%   FreeSurfer subject root directory, i.e. $SUBJECTS_DIR/<subject_id>.
%
% - out_dir (1,1) string
%
%   Output directory where atlas point files are written. Must exist.
%
% - atlas_schemes (1,:) string
%
%   One or more FreeSurfer annotation names to process. Supported values:
%     'aparc'          -> Desikan-Killiany (id '36')
%     'aparc.a2009s'   -> Destrieux        (id '76')
%   Other values are matched against the parcellation_schemes registry; if
%   not found they are skipped with a warning.
%
% Outputs:
%
% - points (1,1) struct
%
%   Fields are annotation names (with dots replaced by underscores). Each
%   field is a struct with sub-fields 'left' and 'right' containing the
%   basename of the merged label .asc file relative to out_dir.
%
% If mri_annotation2label or mri_mergelabels are not on PATH, the function
% issues a warning and returns an empty struct.
%
% See also: utilities.fs2zef.config.parcellation_schemes
%

    arguments
        subject_dir (1,1) string
        out_dir     (1,1) string
        atlas_schemes (1,:) string = "aparc"
    end

    points = struct();

    if ~isfolder(out_dir)
        error('build_atlas_points:NoOutDir', ...
            'Output directory does not exist: %s', out_dir);
    end

    if ~isfolder(subject_dir)
        error('build_atlas_points:NoSubjectDir', ...
            'FreeSurfer subject directory does not exist: %s', subject_dir);
    end

    if ~freesurfer_tools_available()
        warning('build_atlas_points:NoFS', ...
            'mri_annotation2label / mri_mergelabels not found on PATH. Skipping atlas point generation.');
        return;
    end

    known = utilities.fs2zef.config.parcellation_schemes();
    ann_to_id = build_annotation_map(known);

    subj_root = char(strip(string(subject_dir)));
    fs_subjects_dir = fileparts(subj_root);
    [~, fs_subject_id] = fileparts(subj_root);

    hemispheres = {'lh', 'rh'};
    sides       = {'left', 'right'};
    label_dir   = fullfile(subject_dir, 'label');

    for s_idx = 1:numel(atlas_schemes)
        ann = char(atlas_schemes(s_idx));

        if ~isKey(ann_to_id, ann)
            warning('build_atlas_points:UnknownScheme', ...
                'Annotation "%s" not found in parcellation registry. Skipping.', ann);
            continue;
        end

        scheme_id  = ann_to_id(ann);
        field_name = matlab.lang.makeValidName(ann);
        pts_struct = struct();

        for h_idx = 1:numel(hemispheres)
            hh   = hemispheres{h_idx};
            side = sides{h_idx};

            annot_path = fullfile(label_dir, [hh '.' ann '.annot']);
            if ~isfile(annot_path)
                warning('build_atlas_points:MissingAnnot', ...
                    'Annotation file not found, skipping %s %s: %s', ...
                    ann, side, annot_path);
                continue;
            end

            pts_name = sprintf('%s_labels_%s.asc', hh, scheme_id);
            pts_path = fullfile(out_dir, pts_name);

            if ~isfile(pts_path)
                tmp_dir = fullfile(out_dir, sprintf('_tmp_%s_%s_%s', hh, ann, scheme_id));
                if ~isfolder(tmp_dir)
                    mkdir(tmp_dir);
                end

                cmd1 = sprintf( ...
                    'mri_annotation2label --subject "%s" --sd "%s" --annotation "%s" --hemi %s --outdir "%s"', ...
                    fs_subject_id, fs_subjects_dir, ann, hh, tmp_dir);

                cmd2 = sprintf('mri_mergelabels -d "%s" -o "%s"', tmp_dir, pts_path);

                ok = run_shell_cmd(cmd1) && run_shell_cmd(cmd2);

                if isfolder(tmp_dir)
                    try
                        rmdir(tmp_dir, 's');
                    catch
                    end
                end

                if ~ok
                    warning('build_atlas_points:LabelFailed', ...
                        'Could not generate %s (annotation2label/mergelabels failed).', pts_name);
                end
            end

            if isfile(pts_path)
                pts_struct.(side) = pts_name;
            end
        end

        if ~isempty(fieldnames(pts_struct))
            points.(field_name) = pts_struct;
        end
    end

end % function

function available = freesurfer_tools_available()
    [s1, ~] = system('which mri_annotation2label 2>/dev/null');
    [s2, ~] = system('which mri_mergelabels 2>/dev/null');
    available = (s1 == 0) && (s2 == 0);
end % function

function m = build_annotation_map(known)
    m = containers.Map('KeyType', 'char', 'ValueType', 'char');
    fields = fieldnames(known);
    for ii = 1:numel(fields)
        f = fields{ii};
        if isstruct(known.(f)) && isfield(known.(f), 'annotation') && isfield(known.(f), 'id')
            m(known.(f).annotation) = known.(f).id;
        end
    end
end % function

function ok = run_shell_cmd(cmd)
    [status, out] = system(cmd);
    if status ~= 0
        warning('build_atlas_points:CmdFailed', ...
            'Command failed (exit %d):\n  %s\nOutput: %s', status, cmd, out);
        ok = false;
    else
        ok = true;
    end
end % function
